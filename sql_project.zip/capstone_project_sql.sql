SELECT * FROM amazon;
#Feature engineering - Adding new features(COLUMNS) as per our requirement.
alter table amazon add month varchar(200);
update amazon set month=month(Date);

alter table amazon add day_of_week text;
update amazon set day_of_week = DAYNAME(Date);
alter table amazon add day_week text;
update amazon set day_week = 
CASE WEEKDAY(Date)
	when 5 then 'weekend'
    when 6 then 'weekend'
    else 'weekday'
END;
alter table amazon add timeofday varchar(50);

# 1 .What is the count of distinct cities in the dataset?
SELECT COUNT(DISTINCT city) AS distinct_city_count
FROM amazon;

# 2. For each branch, what is the corresponding city?
SELECT branch, city
FROM amazon
GROUP BY branch, city;

#  3.What is the count of distinct product lines in the dataset?
SELECT count(distinct 'product line') FROM amazon;
SELECT 'product line' FROM amazon GROUP BY 'product line';

# 4. Which payment method occurs most frequently?
SELECT max(payment) from amazon;

# 5. Which product line has the highest sales?
SELECT 'product line' , sum(total) as total_sales 
FROM amazon
GROUP BY 'product line' 
order by total_sales desc 
limit 1;

# 6. How much revenue is generated each month?
select month, sum(cogs) as revenue_generated from amazon group by month;

# 7. In which month did the cost of goods sold reach its peak?
SELECT EXTRACT(MONTH FROM date) AS month, 
       SUM(cogs) AS total_cogs
FROM amazon
GROUP BY month
LIMIT 1;

# 8. Which product line generated the highest revenue?
select 'Product line' , sum(cogs) as revenue_products from amazon group by 'Product line' order by revenue_products desc limit 1;

#9. In which city was the highest revenue recorded?
select city, sum(cogs) as revenue_city from amazon group by City order by revenue_city desc limit 1;

#10. Which product line incurred the highest Value Added Tax?
select 'Product line',sum('Tax 5%') as vat from amazon group by 'Product line' order by vat desc limit 1;

#11. For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."
alter table amazon add Sales_status varchar(200);
update amazon set Sales_status=
case
when "select total from amazon" > "select avg(total) from amazon" then "Good"
else "Bad"

end ;

#12.Identify the branch that exceeded the average number of products sold.
select distinct Branch from amazon where Quantity>(select avg(Quantity) from amazon);

#13. Which product line is most frequently associated with each gender?
select 'Product line', Gender, count(Gender) as Gender_count from amazon group by 'Product line',Gender order by Gender_count desc;

#14. Calculate the average rating for each product line.
select 'Product line', avg(Rating) from amazon group by 'Product line';

#15.Count the sales occurrences for each time of day on every weekday.
select day_time, count(cogs)as Sales_count from amazon where day_week="Weekday" group by day_time;

#16.Identify the customer type contributing the highest revenue.
select 'Customer type',sum(cogs) as rev_cust_type from amazon group by 'Customer type' order by rev_cust_type desc limit 1;

#17.Determine the city with the highest VAT percentage.
select City,sum('Tax 5%') as VAT from amazon group by City order by VAT desc limit 1;

#18. Identify the customer type with the highest VAT payments.
select 'Customer type',sum('Tax 5%') as VAT from amazon group by 'Customer type' order by VAT desc limit 1;

#19. What is the count of distinct customer types in the dataset?
select 'Customer type', count('Customer type') from amazon group by 'Customer type';

#20. What is the count of distinct payment methods in the dataset?
select count( distinct payment) from amazon group by pa;

#21. Which customer type occurs most frequently?
select 'Customer type', count('Customer type') as cust_count from amazon group by 'Customer type' order by cust_count desc limit 1 ;

#22. Identify the customer type with the highest purchase frequency.
select 'Customer type', count('Invoice ID') as pur_freq from amazon group by 'Customer type' order by pur_freq desc limit 1;

#23. Determine the predominant gender among customers.
select gender, count(Gender) from amazon group by Gender limit 1;

#24. Examine the distribution of genders within each branch.
select Branch, gender, count(Gender) from amazon group by Branch,Gender order by Branch;

# 25. Identify the time of day when customers provide the most ratings.
select timeofday, count(rating) as rating_count from amazon
where rating is not null
group by timeofday
order by rating_count desc;

# 26. Determine the time of day with the highest customer ratings for each branch.
select branch, timeofday, max(rating) as highest_customer_rating
from amazon group by branch, timeofday
order by highest_customer_rating desc;

#27. Identify the day of the week with the highest average ratings.
select dayname(date) as day_of_the_week, avg(rating) as average_rating
from amazon group by day_of_the_week order by average_rating desc;

# 28 .Determine the day of the week with the highest average ratings for each branch.
select branch , dayname(date) as day_of_the_week, avg(rating) as Average_rating
from amazon group by branch ,day_of_the_week order by Average_rating desc;

